package cn.bran.play;


/**
 * not used yet
 * @author Bing Ran<bing_ran@hotmail.com>
 *
 */
public class Japid {

	public static void shutdown() {
		// TODO Auto-generated method stub
//		System.out.println("Japid shutdown called");
		
	}

	public static void startup() {
		// let's bind the message provider
//		System.out.println("Japid startup called");

	}

}
