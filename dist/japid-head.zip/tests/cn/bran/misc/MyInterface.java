package cn.bran.misc;

public interface MyInterface {
	public void doSomething(int i);
}