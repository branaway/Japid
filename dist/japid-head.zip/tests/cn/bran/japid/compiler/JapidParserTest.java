package cn.bran.japid.compiler;

import org.junit.Test;

public class JapidParserTest {
	@Test
	public void testOpenBraceInNewLine() {
		
	}
}
