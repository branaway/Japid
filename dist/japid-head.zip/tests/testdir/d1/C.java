package testdir.d1;

public class C {

}
