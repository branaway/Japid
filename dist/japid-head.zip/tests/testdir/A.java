package testdir;

public class A {
//
}
