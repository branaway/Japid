package cn.bran.play;

import cn.bran.japid.template.JapidTemplateBase;


public class Japid {

	public static void shutdown() {
		// TODO Auto-generated method stub
		System.out.println("Japid shutdown called");
		
	}

	public static void startup() {
		// let's bind the message provider
		System.out.println("Japid startup called");

	}

}
