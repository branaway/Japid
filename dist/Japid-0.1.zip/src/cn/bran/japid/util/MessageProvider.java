package cn.bran.japid.util;

public interface MessageProvider {
	String getMessage(String msgName, Object... args);
}
