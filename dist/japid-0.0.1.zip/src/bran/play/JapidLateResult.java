package bran.play;

/**
 * the rendering process takes place slight later in the controller
 * . There is no real difference at all! Proabably not useful. 
 * @author bran
 *
 */
public class JapidLateResult {

}
