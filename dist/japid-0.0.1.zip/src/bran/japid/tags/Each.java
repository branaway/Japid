package bran.japid.tags;

import java.io.OutputStream;
import java.util.Collection;
import java.util.Iterator;

// This file was generated from: tag/Each.html
// Change to this file will be lost next time the template file is compiled.
public class Each extends bran.japid.BranTemplateBase {
	public static final String sourceTemplate = "tag/Each.html";

	public Each(OutputStream out) {
		super(out);
	}


	public void render(Iterable it, DoBody body) {
		Iterator itor = it.iterator();
		itBody(body, itor);
	}

	// TODO:  more polymorphic renders
	
	/**
	 * @param body
	 * @param it
	 */
	private void itBody(DoBody body, Iterator it) {
		int start = 0;
		int i = 0;
		while(it.hasNext()) {
			i++;
			Object o =it.next();
			body.render(o, i, i % 2 == 0, i == start + 1, it.hasNext() ? false : true);
		}
	}

	@Override
	protected void doLayout() {
		// dummy
	}
	
	public static interface DoBody<E> {
		void render(E _, int _index, boolean _isOdd, boolean _first, boolean _last);
	}
}
